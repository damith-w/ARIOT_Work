rtObjectRecognition
===================

Real Time Object Recognition using SURF algorithm in OpenCV EEL6562 Course Project

Note: OpenCV libraries must be installed to use code. See link below on how to install OpenCV

http://nenadbulatovic.blogspot.com/2013/07/configuring-opencv-245-eclipse-cdt-juno.html
